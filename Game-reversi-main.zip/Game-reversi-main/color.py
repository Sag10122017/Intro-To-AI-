class Color:
    
    def __init__(self):

        self.pinkBg = (195, 161, 159) # pink background for program
        self.grey = (205, 195, 194)
        self.lightPink = (245, 225, 218) # light pink board background + end_screen color
        self.purple = (111, 91, 130)
        self.red = (201, 127, 102)
        self.indicateColor = (255, 0, 0)