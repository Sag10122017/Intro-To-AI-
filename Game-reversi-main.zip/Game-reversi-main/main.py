import pygame
from othello import *

if __name__ == '__main__':
    game = Othello()
    game.run()
    pygame.quit()